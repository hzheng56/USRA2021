import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Author: Hao Zheng
 *
 * This code is used for processing COVID-19 metadata .csv file, including:
 * 1) Split the original files into multiple smaller sized files by year values then output them.
 * 2) Generate multiple files by hospitalization status and then regions for each week, month, and quarter.
 * 3) todo: correct the monthly file generation section to make it more precisely.
 * 4) todo: calculate input data for statistic purposes.
 */
public class csvProcessor
{
	private static ArrayList<String[]> rows;	// store all data in an entire .csv file
	private static final int WEEKS = 52;	// max value of COV_EW is 52 (except unknown)
	private static String nameYear;	// label for directory name
	private static int startWeek;	// label for counting week

	/* Main method */
	public static void main(String[] args)
	{
		/* Initialize variables */
		String srcPath = "";	// may require changes
		String srcName = "COVID19-eng.csv";
		rows = new ArrayList<>();
		int colRegion = 1;
		int colWeek = 2;
		int colYear = 4;
		int colIcu = 11;

		/* Read file */
		readCSV(srcPath + srcName);

		/* Split the original file by years, output new files */
		splitCSV_year(srcPath, rows, colYear, 20);
		splitCSV_year(srcPath, rows, colYear, 21);
		splitCSV_year(srcPath, rows, colYear, 99);

		/* Generate new files, as per week, month, and quarter */
		String[] dir_hp_status = {"hp_status/hp_icu/", "hp_status/hp_non_icu/", "hp_status/non_hp/"};
		String[] dir_region = {"Atlantic/", "Quebec/", "Ontario & Nunavut/", "Prairies/", "British Columbia & Yukon/"};

		String filePath = dir_hp_status[0] + dir_region[0];
		String outputPath;




		/* 1st screening: select entries that have required COV_HSP values in Canada */
		// hp_status_all.get(0): entries in Canada that are hospitalized and in ICU
		// hp_status_all.get(1): entries in Canada that are hospitalized but not in ICU
		// hp_status_all.get(2): entries in Canada that are not hospitalized
		ArrayList<ArrayList<String[]>> hp_status_all = new ArrayList<>();
		for (int i = 1; i <= dir_hp_status.length; i++) {
			ArrayList<String[]> temp = getEntry(rows, colIcu, i);
			hp_status_all.add(temp);
		}

		//生成文件
		for (int i = 0; i < dir_hp_status.length; i++) {
			outputPath = srcPath + "outputs/" + dir_hp_status[i] + "Canada/";

			getCSV(srcPath, dir_hp_status[i] + "Canada/", getPeriod(hp_status_all.get(i), colYear, colWeek, 20), colWeek);
			getCSV(srcPath, dir_hp_status[i] + "Canada/", getPeriod(hp_status_all.get(i), colYear, colWeek, 21), colWeek);
		}

		/* 2nd screening: based on the 1st screening, split entries by different COV_REG values */
		// region_hs1: entries in each region that are hospitalized and in ICU
		// region_hs2: entries in each region that are hospitalized but not in ICU
		// region_hs3: entries in each region that are not hospitalized
		ArrayList<ArrayList<String[]>> region_hs1 = new ArrayList<>();
		ArrayList<ArrayList<String[]>> region_hs2 = new ArrayList<>();
		ArrayList<ArrayList<String[]>> region_hs3 = new ArrayList<>();
		for (int i = 1; i <= dir_region.length; i++) {
			ArrayList<String[]> temp = getEntry(hp_status_all.get(0), colRegion, i);
			region_hs1.add(temp);
		}
		for (int i = 1; i <= dir_region.length; i++) {
			ArrayList<String[]> temp = getEntry(hp_status_all.get(1), colRegion, i);
			region_hs2.add(temp);
		}
		for (int i = 1; i <= dir_region.length; i++) {
			ArrayList<String[]> temp = getEntry(hp_status_all.get(2), colRegion, i);
			region_hs3.add(temp);
		}

		//生成文件
		for (int i = 0; i < dir_region.length; i++) {
			getCSV(srcPath, dir_hp_status[0] + dir_region[i], getPeriod(region_hs1.get(i), colYear, colWeek, 20), colWeek);
			getCSV(srcPath, dir_hp_status[1] + dir_region[i], getPeriod(region_hs1.get(i), colYear, colWeek, 20), colWeek);
			getCSV(srcPath, dir_hp_status[2] + dir_region[i], getPeriod(region_hs1.get(i), colYear, colWeek, 20), colWeek);
			getCSV(srcPath, dir_hp_status[0] + dir_region[i], getPeriod(region_hs1.get(i), colYear, colWeek, 21), colWeek);
			getCSV(srcPath, dir_hp_status[1] + dir_region[i], getPeriod(region_hs1.get(i), colYear, colWeek, 21), colWeek);
			getCSV(srcPath, dir_hp_status[2] + dir_region[i], getPeriod(region_hs1.get(i), colYear, colWeek, 21), colWeek);

			getCSV(srcPath, dir_hp_status[0] + dir_region[i], getPeriod(region_hs2.get(i), colYear, colWeek, 20), colWeek);
			getCSV(srcPath, dir_hp_status[1] + dir_region[i], getPeriod(region_hs2.get(i), colYear, colWeek, 20), colWeek);
			getCSV(srcPath, dir_hp_status[2] + dir_region[i], getPeriod(region_hs2.get(i), colYear, colWeek, 20), colWeek);
			getCSV(srcPath, dir_hp_status[0] + dir_region[i], getPeriod(region_hs2.get(i), colYear, colWeek, 21), colWeek);
			getCSV(srcPath, dir_hp_status[1] + dir_region[i], getPeriod(region_hs2.get(i), colYear, colWeek, 21), colWeek);
			getCSV(srcPath, dir_hp_status[2] + dir_region[i], getPeriod(region_hs2.get(i), colYear, colWeek, 21), colWeek);

			getCSV(srcPath, dir_hp_status[0] + dir_region[i], getPeriod(region_hs3.get(i), colYear, colWeek, 20), colWeek);
			getCSV(srcPath, dir_hp_status[1] + dir_region[i], getPeriod(region_hs3.get(i), colYear, colWeek, 20), colWeek);
			getCSV(srcPath, dir_hp_status[2] + dir_region[i], getPeriod(region_hs3.get(i), colYear, colWeek, 20), colWeek);
			getCSV(srcPath, dir_hp_status[0] + dir_region[i], getPeriod(region_hs3.get(i), colYear, colWeek, 21), colWeek);
			getCSV(srcPath, dir_hp_status[1] + dir_region[i], getPeriod(region_hs3.get(i), colYear, colWeek, 21), colWeek);
			getCSV(srcPath, dir_hp_status[2] + dir_region[i], getPeriod(region_hs3.get(i), colYear, colWeek, 21), colWeek);
		}


		/* Statistic outputs */
		//todo
	}



	private static void outputCSV(String path, String ctg, ArrayList<String[]> table, int wkCol) {

		for (int i = 0; i <= WEEKS; i++) {
			String name = "perWeek/" + nameYear + "week_" + i + ".csv";
			ArrayList<String[]> temp = getEntry(table, wkCol, i);
			// avoid generating empty files
			if (temp.size() > 0) {
				generateCSV(path + name, temp);
			}
		}
	}

	private static void outputCSV_year(String path, ArrayList<String[]> table, int col) {

	}


	//|------------------------------------------------------------------------|
	//|                                 METHODS                                |
	//|------------------------------------------------------------------------|

	/**
	 * This methods splits the original data by values of years then output them.
	 * @param path	path to output new .csv files
	 * @param table	the ArrayList that needs to be passed in
	 * @param col	the column number for search, depends on the chosen key
	 * @param key	the key value for search (i.e. which year)
	 */
	private static void splitCSV_year(String path, ArrayList<String[]> table, int col, int key)
	{
		String name = "outputs/year_" + key + ".csv";
		ArrayList<String[]> temp = getEntry(table, col, key);
		if (temp.size() > 0) {
			generateCSV(path + name, temp);
		}


	}


	private static ArrayList<String[]> getMonth(String path, String ctg, ArrayList<String[]> table, int wkCol)
	{
		int[][] month20 = { {0, 4}, {5, 8}, {9, 12}, {13, 17}, {18, 21}, {22, 25},
				{26, 30}, {31, 34}, {35, 39}, {40, 43}, {44, 47}, {48, 52}
		};
		int[][] month21 = { {0, 4}, {5, 8}, {9, 13}, {14, 17}, {18, 21}, {22, 26},
				{27, 30}, {31, 34}, {35, 39}, {40, 43}, {44, 47}, {48, 52}
		};
		ArrayList<String[]> list = new ArrayList<>();

		// generate files by each month
		for (int i = 0; i < month20.length; i++) {

		}
		return list;
	}


	/**
	 * This method generates .csv files contained in different directories based on needs.
	 * @param path	path to output new .csv files
	 * @param ctg	name of subdirectory (i.e. hospitalization status)
	 * @param table	the ArrayList that needs to be passed in
	 * @param wkCol	column number for COV_EW
	 */
	private static void getCSV(String path, String ctg, ArrayList<String[]> table, int wkCol)
	{
		// generate files by each week
		for (int i = startWeek; i <= WEEKS; i++) {
			String name = "outputs/" + ctg + "perWeek/" + nameYear + "week_" + i + ".csv";
			ArrayList<String[]> temp = getEntry(table, wkCol, i);
			// avoid generating empty files
			if (temp.size() > 0) {
				generateCSV(path + name, temp);
			}
		}

		//todo

		// generate files by each month
		for (int i = startWeek; i <= WEEKS; i += 5) {
			String name = "outputs/" + ctg + "per5Week/" + nameYear + "weeks_" + i + "-" + (i + 4) + ".csv";
			ArrayList<String[]> temp = getEntry(table, wkCol, i);
			for (int j = i + 1; j <= i + 4; j++) {
				temp.addAll(getEntry(table, wkCol, j));
			}
			// avoid generating empty files
			if (temp.size() > 0) {
				generateCSV(path + name, temp);
			}
		}

		// generate files by each quarter
		for (int i = startWeek; i <= WEEKS; i += 13) {
			String name = "outputs/" + ctg + "perQuarter/" + nameYear + "quarter_" + (i + 12)/13 + ".csv";
			ArrayList<String[]> temp = getEntry(table, wkCol, i);
			for (int j = i + 1; j <= i + 12; j++) {
				temp.addAll(getEntry(table, wkCol, j));
			}
			// avoid generating empty files
			if (temp.size() > 0) {
				generateCSV(path + name, temp);
			}
		}
	}

	/**
	 * This methods splits entries by time period then store them into ArrayLists.
	 * @param table	the ArrayList that needs to be passed in
	 * @param yrCol	the column number recording episode year values
	 * @param wkCol	the column number recording episode week values
	 * @param year	episode year values
	 * @return	an ArrayList
	 */
	private static ArrayList<String[]> getPeriod(ArrayList<String[]> table, int yrCol, int wkCol, int year)
	{
		// name the years and choose the start week for each file
		if (year == 20) {
			nameYear = "2020_";
			startWeek = 8;
		} else if (year == 21) {
			nameYear = "2021_";
			startWeek = 1;
		}

		// traverse the table passed in, find the valid entries
		ArrayList<String[]> list = new ArrayList<>();
		for (String[] entry : getEntry(table, yrCol, year)) {
			if (Integer.parseInt(entry[wkCol]) >= 1 && Integer.parseInt(entry[wkCol]) <= WEEKS) {
				list.add(entry);
			}
		}
		return list;
	}

	/**
	 * This method searches entries in a table that passed in, then store them into an ArrayList.
	 * @param table the ArrayList that needs to be passed in
	 * @param col	the column number for search, depends on the chosen key
	 * @param key	the key value for search (i.e. which year)
	 * @return	an ArrayList
	 */
	private static ArrayList<String[]> getEntry(ArrayList<String[]> table, int col, int key)
	{
		ArrayList<String[]> list = new ArrayList<>();
		for (String[] entry : table) {
			if (entry[col].equals(Integer.toString(key))) {
				list.add(entry);
			}
		}
		return list;
	}

	/**
	 * This method generates new .csv data for further outputting operations.
	 * @param path	path to output new .csv files
	 * @param table the ArrayList that needs to be passed in
	 */
	private static void generateCSV(String path, ArrayList<String[]> table)
	{
		String token1 = "[", token2 = "]", token3 = "";
		BufferedWriter bw = null;
		File file = new File(path);
		File fileParent = file.getParentFile();

		// generate directories
		if (!fileParent.exists()) {
			fileParent.mkdirs();
		}

		try {
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8));
		} catch (IOException e) {
			e.printStackTrace();
		}

		// ignore certain strings (i.e. brackets)
		try {
			if (bw != null) {
				// the first row of all files must be same
				bw.write(Arrays.toString(rows.get(0)).replace(token1, token3).replace(token2, token3));
				for (String[] entry : table) {
					bw.newLine();
					bw.write(Arrays.toString(entry).replace(token1, token3).replace(token2, token3));
				}
				bw.flush();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This methods reads a .csv file.
	 * @param path	path where the .csv file locates
	 */
	private static void readCSV(String path)
	{
		// open the .csv file
		BufferedReader br = null;
		File file = new File(path);
		try {
			br = new BufferedReader(new FileReader(file));
		} catch (IOException e) {
			e.printStackTrace();
		}

		// read contents of each row
		String line;
		try {
			if (br != null) {
				while ((line = br.readLine()) != null) {
					rows.add(line.split(","));
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
